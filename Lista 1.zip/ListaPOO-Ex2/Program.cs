﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_Ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Quadrado q;
            q = new Quadrado();

            Console.WriteLine("Informar a aresta");
            q.setAresta(int.Parse(Console.ReadLine()));

            q.calcularArea();
            Console.WriteLine(q.getArea());
         
        }
    }
}
