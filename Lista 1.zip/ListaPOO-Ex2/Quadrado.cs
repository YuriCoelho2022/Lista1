﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_Ex2
{
    internal class Quadrado
    {
        private int a;
        private int area;

        public void setAresta(int x)
        {
            a = x;
        }


        public int getAresta()
        {
           return a;
        }

        public int getArea()
        {
            return area;
        }

        public void calcularArea()
        {
            area = a * a;
        }
    }
}
