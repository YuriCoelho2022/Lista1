﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Retangulo ret;
            ret = new Retangulo();

            Console.Write("Informe a base: ");
            ret.setBase(int.Parse(Console.ReadLine()));
            Console.Write("Informe a altura: ");
            ret.setAltura(int.Parse(Console.ReadLine()));


            ret.calcularArea();

            Console.WriteLine("O retangulo que tem base de {0} e altura de {1} tem área de {2}", ret.getBase(), ret.getAltura(), ret.getArea());

        }
    }
}
