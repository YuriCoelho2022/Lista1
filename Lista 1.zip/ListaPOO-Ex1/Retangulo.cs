﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_Ex1
{
    internal class Retangulo
    {
        private int b;
        private int a;
        private int area;

        public void setBase(int x)
        {
            b = x;
        }

        public void setAltura(int x)
        {
            a = x;
        }

        public int getBase()
        {
            return b;
        }

        public int getAltura()
        {
            return a;
        }

        public int getArea()
        {
            return area;
        }

        public void calcularArea()
        {
            area = b * a;
        }
    }
}
